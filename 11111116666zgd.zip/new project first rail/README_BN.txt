FAST RAIL – Android Starter Project

এই ZIP-এ FAST RAIL-এর প্রাথমিক Android demo project আছে।

যা কাজ করে:
- FAST RAIL home screen
- From / To station input
- Journey date picker
- Train search button (এখন demo notice দেখায়)
- Booking services-এর পরিচিতি

যা এখনো বাস্তব নয়:
- Live train search / seat availability
- PNR lookup
- General / Tatkal / Premium Tatkal ticket issuance
- Payment / cancellation

বাস্তব বুকিং চালুর আগে IRCTC-এর লিখিত অনুমোদন, উপযুক্ত authorised PSP/API integration,
নিরাপত্তা পর্যালোচনা এবং payment-provider setup প্রয়োজন। এই demo কোনো IRCTC service-এর
সঙ্গে যুক্ত নয় এবং টিকিট বিক্রি বা ইস্যু করে না।

APK বানানোর সহজ উপায় (Termux ছাড়াই):
1. ZIP-টি GitHub-এ নতুন repository-তে upload করুন।
2. GitHub repository-র Actions tab খুলুন।
3. "Build FAST RAIL APK" workflow নির্বাচন করে Run workflow চাপুন।
4. Build সফল হলে workflow run-এর Artifacts অংশ থেকে FAST-RAIL-debug-apk download করুন।
5. APK Android ফোনে install করার আগে Android-এর install permission দিন।

অথবা Android Studio-তে project folder খুলে Gradle sync করে Build > Build APK(s) ব্যবহার করুন।

Package: com.fastrail.app
App name: FAST RAIL
