package com.fastrail.app

import android.app.Activity
import android.app.DatePickerDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar

class MainActivity : Activity() {
    private val navy = Color.rgb(12, 28, 58)
    private val blue = Color.rgb(27, 102, 220)
    private val pale = Color.rgb(239, 245, 253)
    private lateinit var fromField: EditText
    private lateinit var toField: EditText
    private lateinit var dateButton: Button
    private var selectedDate = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        selectedDate = today()
        buildScreen()
    }

    private fun today(): String {
        val c = Calendar.getInstance()
        return "%02d/%02d/%04d".format(
            c.get(Calendar.DAY_OF_MONTH),
            c.get(Calendar.MONTH) + 1,
            c.get(Calendar.YEAR)
        )
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pale)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 30)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 22, 22, 24)
            setBackgroundColor(navy)
        }
        header.addView(label("FAST RAIL", 27f, Color.WHITE, true))
        header.addView(label("Book Fast. Travel Smart.", 14f, Color.rgb(210, 225, 248), false))
        header.addView(label("Train journeys made simpler", 13f, Color.WHITE, false).apply {
            setPadding(0, 14, 0, 0)
        })
        content.addView(header, matchWrap())

        content.addView(label("Search trains", 22f, navy, true).apply {
            setPadding(0, 24, 0, 12)
        })

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.WHITE)
        }
        fromField = input("From station (e.g. Howrah)")
        toField = input("To station (e.g. New Delhi)")
        card.addView(label("FROM", 11f, Color.DKGRAY, true))
        card.addView(fromField, matchWrap(10))
        card.addView(label("TO", 11f, Color.DKGRAY, true).apply { setPadding(0, 12, 0, 0) })
        card.addView(toField, matchWrap(10))

        dateButton = Button(this).apply {
            text = "Journey date: $selectedDate"
            setOnClickListener { chooseDate() }
        }
        card.addView(dateButton, matchWrap(12))

        val search = Button(this).apply {
            text = "SEARCH TRAINS"
            setTextColor(Color.WHITE)
            setBackgroundColor(blue)
            setOnClickListener {
                val from = fromField.text.toString().trim()
                val to = toField.text.toString().trim()
                if (from.isEmpty() || to.isEmpty()) {
                    Toast.makeText(this@MainActivity, "Enter both stations first", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(
                        this@MainActivity,
                        "Demo mode: live train search needs an authorised railway data integration.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
        card.addView(search, matchWrap(14))
        content.addView(card, matchWrap())

        content.addView(label("Booking services", 20f, navy, true).apply {
            setPadding(0, 24, 0, 10)
        })
        val services = listOf(
            "General & Tatkal booking",
            "Premium Tatkal information",
            "Live seat availability",
            "Fare enquiry & train schedule",
            "PNR status & booking history",
            "Cancellation information"
        )
        services.forEach { item ->
            val tile = TextView(this).apply {
                text = "  •  $item"
                textSize = 15f
                setTextColor(navy)
                setPadding(16, 15, 16, 15)
                setBackgroundColor(Color.WHITE)
            }
            val lp = matchWrap(6)
            content.addView(tile, lp)
        }

        content.addView(label(
            "DEMO VERSION\nThis app does not sell or issue railway tickets yet. Real booking, live availability, PNR and payments require IRCTC/authorised partner approval and approved APIs.",
            12f, Color.rgb(105, 65, 10), false
        ).apply {
            setPadding(14, 18, 14, 12)
        })

        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        setContentView(root)
    }

    private fun input(hintText: String) = EditText(this).apply {
        hint = hintText
        textSize = 15f
        singleLine = true
        setPadding(12, 10, 12, 10)
        setBackgroundColor(pale)
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun matchWrap(top: Int = 0) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { if (top > 0) topMargin = top }

    private fun chooseDate() {
        val c = Calendar.getInstance()
        DatePickerDialog(
            this,
            { _, year, month, day ->
                selectedDate = "%02d/%02d/%04d".format(day, month + 1, year)
                dateButton.text = "Journey date: $selectedDate"
            },
            c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)
        ).show()
    }
}
